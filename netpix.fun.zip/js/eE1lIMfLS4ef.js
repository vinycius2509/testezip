var _____WB$wombat$assign$function_____ = function(name) {return (self._wb_wombat && self._wb_wombat.local_init && self._wb_wombat.local_init(name)) || self[name]; };
if (!self.__WB_pmw) { self.__WB_pmw = function(obj) { this.__WB_source = obj; return this; } }
{
  let window = _____WB$wombat$assign$function_____("window");
  let self = _____WB$wombat$assign$function_____("self");
  let document = _____WB$wombat$assign$function_____("document");
  let location = _____WB$wombat$assign$function_____("location");
  let top = _____WB$wombat$assign$function_____("top");
  let parent = _____WB$wombat$assign$function_____("parent");
  let frames = _____WB$wombat$assign$function_____("frames");
  let opener = _____WB$wombat$assign$function_____("opener");

(function(a){window.ShareLink=function(b,c){var d,e={},f=function(a){var b=a.substr(0,e.classPrefixLength);return b===e.classPrefix?a.substr(e.classPrefixLength):null},g=function(a){d.on("click",function(){h(a)})},h=function(a){var b="";if(e.width&&e.height){var c=screen.width/2-e.width/2,d=screen.height/2-e.height/2;b="toolbar=0,status=0,width="+e.width+",height="+e.height+",top="+d+",left="+c}var f=ShareLink.getNetworkLink(a,e),g=/^https?:\/\//.test(f),h=g?"":"_self";open(f,h,b)},i=function(){a.each(b.classList,function(){var a=f(this);if(a)return g(a),!1})},j=function(){a.extend(e,ShareLink.defaultSettings,c),["title","text"].forEach(function(a){e[a]=e[a].replace("#","")}),e.classPrefixLength=e.classPrefix.length},k=function(){d=a(b)};(function(){j(),k(),i()})()},ShareLink.networkTemplates={twitter:"https://web.archive.org/web/20221106181501/https://twitter.com/intent/tweet?text={text}\x20{url}",pinterest:"https://web.archive.org/web/20221106181501/https://www.pinterest.com/pin/create/button/?url={url}&media={image}",facebook:"https://web.archive.org/web/20221106181501/https://www.facebook.com/sharer.php?u={url}",vk:"https://web.archive.org/web/20221106181501/https://vkontakte.ru/share.php?url={url}&title={title}&description={text}&image={image}",linkedin:"https://web.archive.org/web/20221106181501/https://www.linkedin.com/shareArticle?mini=true&url={url}&title={title}&summary={text}&source={url}",odnoklassniki:"https://web.archive.org/web/20221106181501/https://connect.ok.ru/offer?url={url}&title={title}&imageUrl={image}",tumblr:"https://web.archive.org/web/20221106181501/https://tumblr.com/share/link?url={url}",google:"https://web.archive.org/web/20221106181501/https://plus.google.com/share?url={url}",digg:"https://web.archive.org/web/20221106181501/https://digg.com/submit?url={url}",reddit:"https://web.archive.org/web/20221106181501/https://reddit.com/submit?url={url}&title={title}",stumbleupon:"https://web.archive.org/web/20221106181501/https://www.stumbleupon.com/submit?url={url}",pocket:"https://web.archive.org/web/20221106181501/https://getpocket.com/edit?url={url}",whatsapp:"https://web.archive.org/web/20221106181501/https://api.whatsapp.com/send?text=*{title}*\n{text}\n{url}",xing:"https://web.archive.org/web/20221106181501/https://www.xing.com/app/user?op=share&url={url}",print:"javascript:print()",email:"mailto:?subject={title}&body={text}\n{url}",telegram:"https://web.archive.org/web/20221106181501/https://telegram.me/share/url?url={url}&text={text}",skype:"https://web.archive.org/web/20221106181501/https://web.skype.com/share?url={url}"},ShareLink.defaultSettings={title:"",text:"",image:"",url:location.href,classPrefix:"s_",width:640,height:480},ShareLink.getNetworkLink=function(a,b){var c=ShareLink.networkTemplates[a].replace(/{([^}]+)}/g,function(a,c){return b[c]||""});if("email"===a){if(-1<b.title.indexOf("&")||-1<b.text.indexOf("&")){var d={text:b.text.replace(/&/g,"%26"),title:b.title.replace(/&/g,"%26"),url:b.url};c=ShareLink.networkTemplates[a].replace(/{([^}]+)}/g,function(a,b){return d[b]})}return c.indexOf("?subject=&body")&&(c=c.replace("subject=&","")),c}return c},a.fn.shareLink=function(b){return this.each(function(){a(this).data("shareLink",new ShareLink(this,b))})}})(jQuery);


}
/*
     FILE ARCHIVED ON 18:15:01 Nov 06, 2022 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 17:18:57 Jul 15, 2023.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  captures_list: 122.674
  exclusion.robots: 0.086
  exclusion.robots.policy: 0.075
  cdx.remote: 0.061
  esindex: 0.009
  LoadShardBlock: 86.713 (3)
  PetaboxLoader3.datanode: 82.111 (4)
  load_resource: 84.215
  PetaboxLoader3.resolve: 48.525
*/