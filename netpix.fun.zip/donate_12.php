<!DOCTYPE html>
  <html lang="en" class="donation-banner-iframe">
    <head><title>Donate</title><style>body{margin:0}</style>
    <meta name="viewport" content="width=device-width, initial-scale=1">
      <script src="js/dBVxpxB2nxe1.js"></script>
      <script src="js/wsY7s39SQuZq.js"></script>
      <script src="js/O5NlIMS98wro.js"></script>
          <script src="js/V3h43JGBV7gT.js" type="text/javascript"></script>
    </head>
    <body class="js-ia-iframe" style="margin:0">
          <link href="css/nRS7RfJ9bAgP.css" rel="stylesheet" type="text/css">
    <link href="css/WTy8oR7MSoRB.css" rel="stylesheet" type="text/css">

    <header id="donate_banner" class="row js-donate-banner template-chevron background-default chevron-image-white  chevron-color-default formdesign-minimal" itemscope itemtype="http://schema.org/WPAdBlock" data-donationSourceData="ctx=wb;uid=f29945b078d7b2c27cb2ed566299adc1;ref=https%3A%2F%2Fweb.archive.org%2Fweb%2F20230715172129%2Fhttps%3A%2F%2FvwMtB7jsTbm4.fun%2Fwp-content%2Fplugins%2Felementor%2Fassets%2Flib%2Ffont-awesome%2Fwebfonts%2Ffa-regular-400.svg" data-exp="July Deploy" data-variant="Jul2023WBminwig2" data-platform="wb" data-baseUrl="https://archive.org" data-bannerTemplate="chevron" data-bannerBackground="default" data-snowfall="off" data-selectedTextColor="#fff" data-selectedFillColor="#23765D" data-paymentOptionFillColor="#23765D" data-paymentOptionTextColor="#fff" data-formBgColor data-formTextColor data-donatePageSelectedTextColor data-donatePageSelectedFillColor data-variantDollarAmounts="[5, 27, 50, 100]" data-debugMode="false" style>
      <button id="donate-close-button" class="donate-close" type="button" aria-label="Close banner">
        <span class="sr-only">Close banner</span>
        <img src="fonts/CF5h31Tt3qg2.svg" id="banner-close-image-dark">
        <img src="fonts/fgFDcnN8fAH9.svg" id="banner-close-image-white">
      </button>
      <div id="banner-body-container" style>
        <div id="banner-body-left-container" class="show-separator" style>
                    <div class="donate-body">
                                      <div id="chevron-image-container" style></div>
            
            <div class="main-content">
              <div class="appeal-text" style>
                Please don't scroll past this. The Internet Archive (which runs the Wayback Machine) is a nonprofit, powered by donations averaging about $27. Join the one in a thousand users that support us financially—if our resources are useful to you, please pitch in.              </div>

                          </div>
            <div id="donate-body-background-layer2" class="supplemental-background-layer"></div>
            <div id="donate-body-background-layer1" class="supplemental-background-layer"></div>
          </div>
        </div>

        <div class="donate-form js-donate-form" itemscope itemtype="http://schema.org/DonateAction">
          <meta itemprop="recipient" content="Internet Archive">
          <meta itemprop="actionStatus" content="PotentialActionStatus">
          <div class="white-box">
                                <div class="donation-form-container">
        <donation-form-edit-donation amountOptions="[5, 27, 50, 100]" amountTitleDisplayMode="slot" customAmountMode="hide" customFeesCheckboxMode="hide" frequencySelectionMode="hide" stepNumberMode="hidenumbers" class="minimal-widget focus-on-child-only" style="--paymentButtonSelectedFontColor: #fff;--paymentButtonSelectedColor: #23765D;--paymentButtonColor: #23765D;--paymentButtonFontColor: #fff;--paymentButtonBorderColor: #fff;">
          <div slot="edit-donation-amount-title">
            <p style="font-size: 1.8rem; line-height: calc(1.2rem * 2); margin: 0;"><b>Can You Chip In?</b> (USD)</p>
          </div>
        </donation-form-edit-donation>
      </div>
                          </div> <!--/.white-box -->
          <div class="donate-form-chevrons" style></div>
        </div> <!-- .donate-form -->
      </div>
    </header>
        </body>
  </html>
